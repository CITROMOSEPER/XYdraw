//XYdraw library source file
//ESP32
//2024/07/25
//Nemes Dániel

#include <Arduino.h>
#include <XYdraw.h>


//constructor funciton
XYdraw::XYdraw(int ch_x_pin, int ch_y_pin, int refine)
{
  _refine = refine;
  _ch_x_pin = ch_x_pin;
  _ch_y_pin = ch_y_pin;
}


//Initializer function
void XYdraw::begin()
{
  pinMode(_ch_x_pin, OUTPUT);
  pinMode(_ch_y_pin, OUTPUT);
}


//Set the quality of splines
void XYdraw::setRefine(int refine)
{
  _refine = refine;
}


//Draws a line from 4 coordinates
void XYdraw::line(int start_x, int start_y, int end_x, int end_y)
{
  for (int i = 0; i <= _refine; i++)
  {
    float t = (float)i / (float)_refine;
    
    // Linear interpolation between the start and end points
    float x = start_x + t * (end_x - start_x);
    float y = start_y + t * (end_y - start_y);

    dacWrite(_ch_x_pin, x);
    dacWrite(_ch_y_pin, y);

    delay(1); // Small delay to ensure DAC output stabilization
  }
}


//Draws a circle from 2 coordinates and a radius
void XYdraw::circle(int origin_x, int origin_y, int radius)
{
  for (float i = 0; i < 360.0; i += 360.0 / (float)_refine)
  {
    dacWrite(_ch_x_pin, origin_x + (sin(radians(i)) * radius));
    dacWrite(_ch_y_pin, origin_y + (cos(radians(i)) * radius));
  }
  delay(1);
}


//Draws a bézier curve from 4 control point coordinates
void XYdraw::bezier_curve(int anchor1_x, int anchor1_y, int anchor2_x, int anchor2_y, int cp1_x, int cp1_y, int cp2_x, int cp2_y)
{
  for (int i = 0; i <= _refine; i++)
  {
    float t = (float)i / (float)_refine;

    // Linear interpolations for the first level
    float x0 = (1 - t) * anchor1_x + t * cp1_x;
    float y0 = (1 - t) * anchor1_y + t * cp1_y;
    float x1 = (1 - t) * cp1_x + t * cp2_x;
    float y1 = (1 - t) * cp1_y + t * cp2_y;
    float x2 = (1 - t) * cp2_x + t * anchor2_x;
    float y2 = (1 - t) * cp2_y + t * anchor2_y;

    // Linear interpolations for the second level
    float x3 = (1 - t) * x0 + t * x1;
    float y3 = (1 - t) * y0 + t * y1;
    float x4 = (1 - t) * x1 + t * x2;
    float y4 = (1 - t) * y1 + t * y2;

    // Linear interpolation for the third level
    float x = (1 - t) * x3 + t * x4;
    float y = (1 - t) * y3 + t * y4;

    // Ensure values are within the DAC range (0-255)
    int dac_x = constrain((int)x, 0, 255);
    int dac_y = constrain((int)y, 0, 255);

    dacWrite(_ch_x_pin, dac_x);
    dacWrite(_ch_y_pin, dac_y);

    delay(1); // Small delay to ensure DAC output stabilization
  }
}


//Draws the number 0
void XYdraw::zero(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x, y - size, x, y - size * 2);
  line(x + size * 2, y - size, x + size * 2, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2 , y - size * 2, x, y - size * 3.5, x + size * 2, y - size * 3.5);
}


//Draws the number 1
void XYdraw::one(int x, int y, int size)
{
  line(x, y - size, x + size, y);
  line(x + size, y, x + size, y - size * 3);
}


//Draws the number 2
void XYdraw::two(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x + size * 2, y - size, x, y - size * 3);
  line(x, y - size * 3, x + size * 2, y - size * 3);
}


//Draws the number 3
void XYdraw::three(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x + size * 2, y - size, x + size, y - size * 1.5);
  line(x + size * 2, y - size * 2, x + size, y - size * 1.5);
  bezier_curve(x, y - size * 2, x + size * 2 , y - size * 2, x, y - size * 3.5, x + size * 2, y - size * 3.5);
}


//Draws the number 4
void XYdraw::four(int x, int y, int size)
{
  line(x + size, y, x, y - size * 2);
  line(x, y - size * 2, x + size * 2, y - size * 2);
  line(x + size, y - size, x + size, y - size * 3);
}


//Draws the number 5
void XYdraw::five(int x, int y, int size)
{
  line(x + size * 2, y, x, y);
  line(x, y, x, y - size);
  bezier_curve(x, y - size, x, y - size * 3, x + size * 2.5, y - size, x + size * 2.5, y - size * 3);
}


//Draws the number 6
void XYdraw::six(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x, y - size, x, y - size * 2);
  circle(x + size, y - size * 2, size);
}


//Draws the number 7
void XYdraw::seven(int x, int y, int size)
{
  line(x, y, x + size * 2, y);
  line(x + size * 2, y, x, y - size * 2);
  line(x + size * 0.5, y - size * 1.5, x + size * 1.5, y - size * 1.5);
}


//Draws the number 8
void XYdraw::eight(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x, y - size, x + size * 2, y - size * 2);
  line(x, y - size * 2, x + size * 2, y - size);
  bezier_curve(x, y - size * 2, x + size * 2 , y - size * 2, x, y - size * 3.5, x + size * 2, y - size * 3.5);
}


//Draws the number 9
void XYdraw::nine(int x, int y, int size)
{
  circle(x + size, y - size, size);
  line(x + size * 2, y - size, x + size * 2, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2 , y - size * 2, x, y - size * 3.5, x + size * 2, y - size * 3.5);
}


//Renders a string starting from the right
void XYdraw::render_string(String input_string, int x, int y, int size, int letter_distance)
{
  for (int i = 0; i < input_string.length(); i++)
  {
    char letter = input_string.charAt(i);
    int offset = i * (size + letter_distance);
    switch (letter)
    {
      case '0':
        zero(x + offset, y, size);
        break;
      case '1':
        one(x + offset, y, size);
        break;
      case '2':
        two(x + offset, y, size);
        break;
      case '3':
        three(x + offset, y, size);
        break;
      case '4':
        four(x + offset, y, size);
        break;
      case '5':
        five(x + offset, y, size);
        break;
      case '6':
        six(x + offset, y, size);
        break;
      case '7':
        seven(x + offset, y, size);
        break;
      case '8':
        eight(x + offset, y, size);
        break;
      case '9':
        nine(x + offset, y, size);
        break;
    }
  }
}


//Renders a string starting from the right
void XYdraw::render_reverse_string(String input_string, int x, int y, int size, int letter_distance)
{
  x -= (input_string.length() * (size + letter_distance));
  for (int i = 0; i < input_string.length(); i++)
  {
    char letter = input_string.charAt(i);
    int offset = i * (size + letter_distance);
    switch (letter)
    {
      case '0':
        zero(x + offset, y, size);
        break;
      case '1':
        one(x + offset, y, size);
        break;
      case '2':
        two(x + offset, y, size);
        break;
      case '3':
        three(x + offset, y, size);
        break;
      case '4':
        four(x + offset, y, size);
        break;
      case '5':
        five(x + offset, y, size);
        break;
      case '6':
        six(x + offset, y, size);
        break;
      case '7':
        seven(x + offset, y, size);
        break;
      case '8':
        eight(x + offset, y, size);
        break;
      case '9':
        nine(x + offset, y, size);
        break;
    }
  }
}