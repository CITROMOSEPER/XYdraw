//XYdraw library source file
//ESP32
//2024/07/25
//Nemes Dániel

#include <Arduino.h>
#include <XYdraw.h>

//*_ _
//|   |
//|   |
//|   |
// - -



//Constructor funciton
XYdraw::XYdraw(int ch_x_pin, int ch_y_pin, int refine)
{
  _refine = refine;
  _ch_x_pin = ch_x_pin;
  _ch_y_pin = ch_y_pin;
}


//Initializer function
void XYdraw::begin()
{
  pinMode(_ch_x_pin, OUTPUT);
  pinMode(_ch_y_pin, OUTPUT);
}


//Set the quality of splines
void XYdraw::setRefine(unsigned int refine)
{
  _refine = refine;
}


//Draws a line from 4 coordinates
void XYdraw::line(int start_x, int start_y, int end_x, int end_y)
{
  for (int i = 0; i <= _refine; i++)
  {
    float t = (float)i / (float)_refine;
    
    // Linear interpolation between the start and end points
    float x = start_x + t * (end_x - start_x);
    float y = start_y + t * (end_y - start_y);

    dacWrite(_ch_x_pin, x);
    dacWrite(_ch_y_pin, y);

    delay(1); // Small delay to ensure DAC output stabilization
  }
}


void XYdraw::rectangle(int x, int y, int x_length, int y_length)
{
  line(x, y, x + x_length, y);
  line(x + x_length, y, x + x_length, y + y_length);
  line(x + x_length, y + y_length, x, y + y_length);
  line(x, y + y_length, x, y);
}


//Draws a circle from 2 coordinates and a radius
void XYdraw::circle(int origin_x, int origin_y, int radius)
{
  for (float i = 0; i < 360.0; i += 360.0 / (float)_refine)
  {
    dacWrite(_ch_x_pin, origin_x + (sin(radians(i)) * radius));
    dacWrite(_ch_y_pin, origin_y + (cos(radians(i)) * radius));
  }
  delay(1);
}


//Draws a bézier curve from 4 control point coordinates
void XYdraw::bezier_curve(int anchor1_x, int anchor1_y, int anchor2_x, int anchor2_y, int cp1_x, int cp1_y, int cp2_x, int cp2_y)
{
  for (int i = 0; i <= _refine; i++)
  {
    float t = (float)i / (float)_refine;

    // Linear interpolations for the first level
    float x0 = (1 - t) * anchor1_x + t * cp1_x;
    float y0 = (1 - t) * anchor1_y + t * cp1_y;
    float x1 = (1 - t) * cp1_x + t * cp2_x;
    float y1 = (1 - t) * cp1_y + t * cp2_y;
    float x2 = (1 - t) * cp2_x + t * anchor2_x;
    float y2 = (1 - t) * cp2_y + t * anchor2_y;

    // Linear interpolations for the second level
    float x3 = (1 - t) * x0 + t * x1;
    float y3 = (1 - t) * y0 + t * y1;
    float x4 = (1 - t) * x1 + t * x2;
    float y4 = (1 - t) * y1 + t * y2;

    // Linear interpolation for the third level
    float x = (1 - t) * x3 + t * x4;
    float y = (1 - t) * y3 + t * y4;

    // Ensure values are within the DAC range (0-255)
    int dac_x = constrain((int)x, 0, 255);
    int dac_y = constrain((int)y, 0, 255);

    dacWrite(_ch_x_pin, dac_x);
    dacWrite(_ch_y_pin, dac_y);

    delay(1); // Small delay to ensure DAC output stabilization
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Draws a negative sign
void XYdraw::minus(int x, int y, int size)
{
  line(x, y - size * 1.5, x + size * 2, y - size * 1.5);
}


//Draws the number 0
void XYdraw::zero(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x + size * 2, y - size, x + size * 2, y - size * 2);
  bezier_curve(x + size * 2, y - size * 2, x, y - size * 2, x + size * 2, y - size * 3, x, y - size * 3);
  line(x, y - size * 2, x, y - size);
}


//Draws the number 1
void XYdraw::one(int x, int y, int size)
{
  line(x, y - size, x + size, y);
  line(x + size, y, x + size, y - size * 3);
}


//Draws the number 2
void XYdraw::two(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x + size * 2, y - size, x, y - size * 3);
  line(x, y - size * 3, x + size * 2, y - size * 3);
}


//Draws the number 3
void XYdraw::three(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x + size * 2, y - size, x + size, y - size * 1.5);
  line(x + size * 2, y - size * 2, x + size, y - size * 1.5);
  bezier_curve(x, y - size * 2, x + size * 2 , y - size * 2, x, y - size * 3.5, x + size * 2, y - size * 3.5);
}


//Draws the number 4
void XYdraw::four(int x, int y, int size)
{
  line(x + size, y, x, y - size * 2);
  line(x, y - size * 2, x + size * 2, y - size * 2);
  line(x + size, y - size, x + size, y - size * 3);
}


//Draws the number 5
void XYdraw::five(int x, int y, int size)
{
  line(x + size * 2, y, x, y);
  line(x, y, x, y - size);
  bezier_curve(x, y - size, x, y - size * 3, x + size * 2.5, y - size, x + size * 2.5, y - size * 3);
}


//Draws the number 6
void XYdraw::six(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x, y - size, x, y - size * 2);
  circle(x + size, y - size * 2, size);
}


//Draws the number 7
void XYdraw::seven(int x, int y, int size)
{
  line(x, y, x + size * 2, y);
  line(x + size * 2, y, x, y - size * 2);
  line(x + size * 0.5, y - size * 1.5, x + size * 1.5, y - size * 1.5);
}


//Draws the number 8
void XYdraw::eight(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x, y - size, x + size * 2, y - size * 2);
  line(x, y - size * 2, x + size * 2, y - size);
  bezier_curve(x, y - size * 2, x + size * 2 , y - size * 2, x, y - size * 3.5, x + size * 2, y - size * 3.5);
}


//Draws the number 9
void XYdraw::nine(int x, int y, int size)
{
  circle(x + size, y - size, size);
  line(x + size * 2, y - size, x + size * 2, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2 , y - size * 2, x, y - size * 3.5, x + size * 2, y - size * 3.5);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Draws the letter A
void XYdraw::DRAW_A(int x, int y, int size)
{
  line(x, y - size * 3, x + size, y);
  line(x + size, y, x + size * 2, y - size * 3);
  line(x + size * 0.333, y - size * 2, x + size * 1.666, y - size * 2);
}


//Draws the letter B
void XYdraw::DRAW_B(int x, int y, int size)
{
  line(x, y - size * 3, x, y);
  bezier_curve(x, y, x, y - size * 1.5, x + size, y, x + size, y - size * 1.5);
  bezier_curve(x, y - size * 1.5, x, y - size * 3, x + size * 2, y - size * 1.5, x + size * 2, y - size * 3);
}


//Draws the letter C
void XYdraw::DRAW_C(int x, int y, int size)
{
  bezier_curve(x + size * 2, y - size, x, y - size, x + size * 2, y, x, y);
  line(x, y - size, x, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2, x, y - size * 3, x + size * 2, y - size * 3);
}


//Draws the letter D
void XYdraw::DRAW_D(int x, int y, int size)
{
  line(x, y, x, y - size * 3);
  bezier_curve(x, y - size * 3, x, y, x + size * 2, y - size * 3, x + size * 2, y);
}


//Draws the letter E
void XYdraw::DRAW_E(int x, int y, int size)
{
  line(x + size * 2, y, x, y);
  line(x, y, x, y - size * 3);
  line(x, y - size * 3, x + size * 2, y - size * 3);
  line(x, y - size * 1.5, x + size * 2, y - size * 1.5);
}


//Draws the letter F
void XYdraw::DRAW_F(int x, int y, int size)
{
  line(x + size * 2, y, x, y);
  line(x, y, x, y - size * 3);
  line(x, y - size * 1.5, x + size * 1.8, y - size * 1.5);
}


//Draws the letter G
void XYdraw::DRAW_G(int x, int y, int size)
{
  bezier_curve(x + size * 2, y - size, x, y - size, x + size * 2, y, x, y);
  line(x, y - size, x, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2, x, y - size * 3, x + size * 2, y - size * 3);
  line(x + size * 2, y - size * 2, x + size * 2, y - size * 1.5);
  line(x + size * 2, y - size * 1.5, x + size, y - size * 1.5);
}


//Draws the letter H
void XYdraw::DRAW_H(int x, int y, int size)
{
  line(x, y, x, y - size * 3);
  line(x, y - size * 1.5, x + size * 2, y - size * 1.5);
  line(x + size * 2, y, x + size * 2, y - size * 3);
}


//Draws the letter I
void XYdraw::DRAW_I(int x, int y, int size)
{
  line(x + size, y, x + size, y - size *3);
}


//Draws the letter J
void XYdraw::DRAW_J(int x, int y, int size)
{
  line(x + size * 2, y, x + size * 2, y - size * 2);
  bezier_curve(x + size * 2, y - size * 2, x, y - size * 2, x + size * 2, y - size * 3, x, y - size * 3);
}


//Draws the letter K
void XYdraw::DRAW_K(int x, int y, int size)
{
  line(x, y, x, y - size * 3);
  line(x, y - size * 2, x + size * 2, y);
  line(x + size * 2, y - size * 3, x, y - size * 2);
}


//Draws the letter L
void XYdraw::DRAW_L(int x, int y, int size)
{
  line(x, y, x, y - size * 3);
  line(x, y - size * 3, x + size * 2, y - size * 3);
}


//Draws the letter M
void XYdraw::DRAW_M(int x, int y, int size)
{
  line(x, y - size * 3, x, y);
  line(x, y, x + size, y - size);
  line(x + size, y - size, x + size * 2, y);
  line(x + size * 2, y, x + size * 2, y - size * 3);
}


//Draws the letter N
void XYdraw::DRAW_N(int x, int y, int size)
{
  line(x, y - size * 3, x, y);
  line(x, y, x + size * 2, y - size * 3);
  line(x + size * 2, y - size * 3, x + size * 2, y);
}


//Draws the letter O
void XYdraw::DRAW_O(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x + size * 2, y - size, x + size * 2, y - size * 2);
  bezier_curve(x + size * 2, y - size * 2, x, y - size * 2, x + size * 2, y - size * 3, x, y - size * 3);
  line(x, y - size * 2, x, y - size);
}


//Draws the letter P
void XYdraw::DRAW_P(int x, int y, int size)
{
  line(x, y - size * 3, x, y);
  bezier_curve(x, y, x, y - size * 1.5, x + size * 2, y, x + size * 2, y - size * 1.5);
}


//Draws the letter Q
void XYdraw::DRAW_Q(int x, int y, int size)
{
  bezier_curve(x, y - size, x + size * 2 , y - size, x, y + size * 0.2, x + size * 2, y + size * 0.5);
  line(x + size * 2, y - size, x + size * 2, y - size * 2);
  bezier_curve(x + size * 2, y - size * 2, x, y - size * 2, x + size * 2, y - size * 3, x, y - size * 3);
  line(x, y - size * 2, x, y - size);
  line(x + size, y - size * 2, x + size * 2, y - size * 3);
}


//Draws the letter R
void XYdraw::DRAW_R(int x, int y, int size)
{
  line(x, y - size * 3, x, y);
  bezier_curve(x, y, x, y - size * 1.5, x + size * 2, y, x + size * 2, y - size * 1.5);
  line(x, y - size * 1.5, x + size * 2, y - size * 3);
}


//Draws the letter S
void XYdraw::DRAW_S(int x, int y, int size)
{
  bezier_curve(x + size * 2, y - size, x, y - size, x + size * 2, y, x, y);
  bezier_curve(x, y - size, x + size * 2, y - size * 2, x, y - size * 2, x + size * 2, y - size);
  bezier_curve(x + size * 2, y - size * 2, x, y - size * 2, x + size * 2, y - size * 3, x, y - size * 3);
}


//Draws the letter T
void XYdraw::DRAW_T(int x, int y, int size)
{
  line(x, y, x + size * 2, y);
  line(x + size, y, x + size, y - size * 3);
}


//Draws the letter U
void XYdraw::DRAW_U(int x, int y, int size)
{
  line(x, y, x, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2, x, y - size * 3, x + size * 2, y - size * 3);
  line(x + size * 2, y - size * 2, x + size * 2, y);
}


//Draws the letter V
void XYdraw::DRAW_V(int x, int y, int size)
{
  line(x, y, x + size, y - size * 3);
  line(x + size, y - size * 3, x + size * 2, y);
}


//Draws the letter W
void XYdraw::DRAW_W(int x, int y, int size)
{
  line(x, y, x + size * 0.5, y - size * 3);
  line(x + size * 0.5, y - size * 3, x + size, y - size * 2);
  line(x + size, y - size * 2, x + size * 1.5, y - size * 3);
  line(x + size * 1.5, y - size * 3, x + size * 2, y);
}


//Draws the letter X
void XYdraw::DRAW_X(int x, int y, int size)
{
  line(x, y, x + size * 2, y - size * 3);
  line(x, y - size * 3, x + size * 2, y);
}


//Draws the letter Y
void XYdraw::DRAW_Y(int x, int y, int size)
{
  line(x, y, x + size, y - size);
  line(x + size * 2, y, x, y - size * 3);
}


//Draws the letter Z
void XYdraw::DRAW_Z(int x, int y, int size)
{
  line(x, y, x + size * 2, y);
  line(x + size * 2, y, x, y - size * 3);
  line(x, y - size * 3, x + size * 2, y - size * 3);
}



//Draws the letter a
void XYdraw::DRAW_a(int x, int y, int size)
{
  circle(x + size, y - size * 2, size);
  line(x + size * 2, y - size * 3, x + size * 2, y - size * 1.5);
  bezier_curve(x + size * 2, y - size * 1.5, x, y - size * 1.5, x + size * 2, y - size * 0.5, x, y - size * 0.5);
}


//Draws the letter b
void XYdraw::DRAW_b(int x, int y, int size)
{
  circle(x + size, y - size * 2, size);
  line(x, y - size * 3, x, y);
}


//Draws the letter c
void XYdraw::DRAW_c(int x, int y, int size)
{
  bezier_curve(x + size * 2, y - size * 1.5, x, y - size * 1.5, x + size * 2, y - size * 0.5, x, y - size * 0.5);
  line(x, y - size * 1.5, x, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2, x, y - size * 3, x + size * 2, y - size * 3);
}


//Draws the letter d
void XYdraw::DRAW_d(int x, int y, int size)
{
  circle(x + size, y - size * 2, size);
  line(x + size * 2, y - size * 3, x + size * 2, y);
}


//Draws the letter e
void XYdraw::DRAW_e(int x, int y, int size)
{
  line(x, y - size * 1.5, x + size * 2, y - size * 1.5);
  bezier_curve(x + size * 2, y - size * 1.5, x, y - size * 1.5, x + size * 2, y - size * 0.5, x, y - size * 0.5);
  line(x, y - size * 1.5, x, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2, x, y - size * 3, x + size * 2, y - size * 3);
}


//Draws the letter f
void XYdraw::DRAW_f(int x, int y, int size)
{
  bezier_curve(x + size * 2, y - size * 0.5, x + size, y - size * 0.5, x + size * 2, y, x + size, y);
  line(x + size, y - size * 0.5, x + size, y - size * 3);
  line(x, y - size * 1.5, x + size * 2, y - size * 1.5);
}


//Draws the letter g
void XYdraw::DRAW_g(int x, int y, int size)
{
  circle(x + size, y - size * 2, size);
  line(x + size * 2, y - size * 2, x + size * 2, y - size * 3);
  bezier_curve(x + size * 2, y - size * 3, x, y - size * 3, x + size * 2, y - size * 4, x, y - size * 4);
}


//Draws the letter h
void XYdraw::DRAW_h(int x, int y, int size)
{
  line(x, y, x, y - size * 3);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2,  x, y - size, x + size * 2, y - size);
  line(x + size * 2, y - size * 2, x + size * 2, y - size * 3);
}


//Draws the letter i
void XYdraw::DRAW_i(int x, int y, int size)
{
  line(x + size, y, x + size, y - size * 0.5);
  line(x + size, y + size, x + size, y - size * 3);
}


//Draws the letter j
void XYdraw::DRAW_j(int x, int y, int size)
{
  line(x + size * 2, y, x + size * 2, y - size * 0.5);
  line(x + size * 2, y + size, x + size * 2, y - size * 3);
  bezier_curve(x + size * 2, y - size * 3, x, y - size * 3, x + size * 2, y - size * 4, x, y - size * 4);
}


//Draws the letter k
void XYdraw::DRAW_k(int x, int y, int size)
{
  line(x, y, x, y - size * 3);
  line(x, y - size * 2, x + size * 2, y - size);
  line(x + size * 2, y - size * 3, x, y - size * 2);
}


//Draws the letter l
void XYdraw::DRAW_l(int x, int y, int size)
{
  line(x, y, x + size, y);
  line(x + size, y, x + size, y - size * 3);
  line(x, y - size * 3, x + size * 2, y - size * 3);
}


//Draws the letter m
void XYdraw::DRAW_m(int x, int y, int size)
{
  line(x, y - size, x, y - size * 3);
  bezier_curve(x, y - size * 1.5, x + size, y - size * 1.5, x, y - size, x + size, y - size);
  bezier_curve(x + size, y - size * 1.5, x + size * 2, y - size * 1.5, x + size, y - size, x + size * 2, y - size);
  line(x + size * 2, y - size * 1.5, x + size * 2, y - size * 3);
}


//Draws the letter n
void XYdraw::DRAW_n(int x, int y, int size)
{
  line(x, y - size, x, y - size * 3);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2, x, y - size, x + size * 2, y - size);
  line(x + size * 2, y - size * 2, x + size * 2, y - size * 3);
}


//Draws the letter o
void XYdraw::DRAW_o(int x, int y, int size)
{
  circle(x + size, y - size * 2, size);
}


//Draws the letter p
void XYdraw::DRAW_p(int x, int y, int size)
{
  circle(x + size, y - size * 2, size);
  line(x, y - size, x, y - size * 4);
}


//Draws the letter q
void XYdraw::DRAW_q(int x, int y, int size)
{
  circle(x + size, y - size * 2, size);
  line(x + size * 2, y - size, x + size * 2, y - size * 4);
}


//Draws the letter r
void XYdraw::DRAW_r(int x, int y, int size)
{
  line(x, y - size, x, y - size * 3);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2, x, y - size, x + size * 2, y - size);
}


//Draws the letter s
void XYdraw::DRAW_s(int x, int y, int size)
{
  bezier_curve(x + size * 2, y - size * 1.5, x, y - size * 1.5, x + size * 2, y - size, x, y - size);
  bezier_curve(x, y - size * 1.5, x + size * 2, y - size * 2.5, x, y - size * 2, x + size * 2, y - size * 2);
  bezier_curve(x + size * 2, y - size * 2.5, x, y - size * 2.5, x + size * 2, y - size * 3, x, y - size * 3);
}


//Draws the letter t
void XYdraw::DRAW_t(int x, int y, int size)
{
  line(x + size, y, x + size, y - size * 2.5);
  bezier_curve(x + size, y - size * 2.5, x + size * 2, y - size * 2.5, x + size, y - size * 3, x + size * 2, y - size * 3);
  line(x, y - size * 1.5, x + size * 2, y - size * 1.5);
}


//Draws the letter u
void XYdraw::DRAW_u(int x, int y, int size)
{
  line(x, y - size, x, y - size * 2);
  bezier_curve(x, y - size * 2, x + size * 2, y - size * 2, x, y - size * 3, x + size * 2, y - size * 3);
  line(x + size * 2, y - size, x + size * 2, y - size * 3);
}


//Draws the letter v
void XYdraw::DRAW_v(int x, int y, int size)
{
  line(x, y - size, x + size, y - size * 3);
  line(x + size, y - size * 3, x + size * 2, y - size);
}


//Draws the letter w
void XYdraw::DRAW_w(int x, int y, int size)
{
  line(x, y - size, x + size * 0.5, y - size * 3);
  line(x + size * 0.5, y - size * 3, x + size, y - size * 2);
  line(x + size, y - size * 2, x + size * 1.5, y - size * 3);
  line(x + size * 1.5, y - size * 3, x + size * 2, y - size);
}


//Draws the letter x
void XYdraw::DRAW_x(int x, int y, int size)
{
  line(x, y - size, x + size * 2, y - size * 3);
  line(x, y - size * 3, x + size * 2, y - size);
}


//Draws the letter y
void XYdraw::DRAW_y(int x, int y, int size)
{
  line(x, y - size, x + size, y - size * 3);
  line(x + size * 2, y - size, x, y - size * 4);
}


//Draws the letter z
void XYdraw::DRAW_z(int x, int y, int size)
{
  line(x, y - size, x + size * 2, y - size);
  line(x + size * 2, y - size, x, y - size * 3);
  line(x, y - size * 3, x + size * 2, y - size * 3);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Renders a single character
void XYdraw::render_letter(char letter, int x, int y, int offset, int size)
{
  switch (letter)
  {
    case '-':
      minus(x + offset, y, size);
      break;
    case ' ':
      //
      break;
    case '0':
      zero(x + offset, y, size);
      break;
    case '1':
      one(x + offset, y, size);
      break;
    case '2':
      two(x + offset, y, size);
      break;
    case '3':
      three(x + offset, y, size);
      break;
    case '4':
      four(x + offset, y, size);
      break;
    case '5':
      five(x + offset, y, size);
      break;
    case '6':
      six(x + offset, y, size);
      break;
    case '7':
      seven(x + offset, y, size);
      break;
    case '8':
      eight(x + offset, y, size);
      break;
    case '9':
      nine(x + offset, y, size);
      break;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    case 'a':
      DRAW_a(x + offset, y, size);
      break;
    case 'b':
      DRAW_b(x + offset, y, size);
      break;
    case 'c':
      DRAW_c(x + offset, y, size);
      break;
    case 'd':
      DRAW_d(x + offset, y, size);
      break;
    case 'e':
      DRAW_e(x + offset, y, size);
      break;
    case 'f':
      DRAW_f(x + offset, y, size);
      break;
    case 'g':
      DRAW_g(x + offset, y, size);
      break;
    case 'h':
      DRAW_h(x + offset, y, size);
      break;
    case 'i':
      DRAW_i(x + offset, y, size);
      break;
    case 'j':
      DRAW_j(x + offset, y, size);
      break;
    case 'k':
      DRAW_k(x + offset, y, size);
      break;
    case 'l':
      DRAW_l(x + offset, y, size);
      break;
    case 'm':
      DRAW_m(x + offset, y, size);
      break;
    case 'n':
      DRAW_n(x + offset, y, size);
      break;
    case 'o':
      DRAW_o(x + offset, y, size);
      break;
    case 'p':
      DRAW_p(x + offset, y, size);
      break;
    case 'q':
      DRAW_q(x + offset, y, size);
      break;
    case 'r':
      DRAW_r(x + offset, y, size);
      break;
    case 's':
      DRAW_s(x + offset, y, size);
      break;
    case 't':
      DRAW_t(x + offset, y, size);
      break;
    case 'u':
      DRAW_u(x + offset, y, size);
      break;
    case 'v':
      DRAW_v(x + offset, y, size);
      break;
    case 'w':
      DRAW_w(x + offset, y, size);
      break;
    case 'x':
      DRAW_x(x + offset, y, size);
      break;
    case 'y':
      DRAW_y(x + offset, y, size);
      break;
    case 'z':
      DRAW_z(x + offset, y, size);
      break;

    case 'A':
      DRAW_A(x + offset, y, size);
      break;
    case 'B':
      DRAW_B(x + offset, y, size);
      break;
    case 'C':
      DRAW_C(x + offset, y, size);
      break;
    case 'D':
      DRAW_D(x + offset, y, size);
      break;
    case 'E':
      DRAW_E(x + offset, y, size);
      break;
    case 'F':
      DRAW_F(x + offset, y, size);
      break;
    case 'G':
      DRAW_G(x + offset, y, size);
      break;
    case 'H':
      DRAW_H(x + offset, y, size);
      break;
    case 'I':
      DRAW_I(x + offset, y, size);
      break;
    case 'J':
      DRAW_J(x + offset, y, size);
      break;
    case 'K':
      DRAW_K(x + offset, y, size);
      break;
    case 'L':
      DRAW_L(x + offset, y, size);
      break;
    case 'M':
      DRAW_M(x + offset, y, size);
      break;
    case 'N':
      DRAW_N(x + offset, y, size);
      break;
    case 'O':
      DRAW_O(x + offset, y, size);
      break;
    case 'P':
      DRAW_P(x + offset, y, size);
      break;
    case 'Q':
      DRAW_Q(x + offset, y, size);
      break;
    case 'R':
      DRAW_R(x + offset, y, size);
      break;
    case 'S':
      DRAW_S(x + offset, y, size);
      break;
    case 'T':
      DRAW_T(x + offset, y, size);
      break;
    case 'U':
      DRAW_U(x + offset, y, size);
      break;
    case 'V':
      DRAW_V(x + offset, y, size);
      break;
    case 'W':
      DRAW_W(x + offset, y, size);
      break;
    case 'X':
      DRAW_X(x + offset, y, size);
      break;
    case 'Y':
      DRAW_Y(x + offset, y, size);
      break;
    case 'Z':
      DRAW_Z(x + offset, y, size);
      break;
  }
}


//Renders a string starting from the left
void XYdraw::render_string(String input_string, int x, int y, int size, int letter_distance)
{
  for (int i = 0; i < input_string.length(); i++)
  {
    char letter = input_string.charAt(i);
    int offset = i * (size + letter_distance);
    render_letter(letter, x, y, offset, size);
  }
}


//Renders a string starting from the right
void XYdraw::render_reverse_string(String input_string, int x, int y, int size, int letter_distance)
{
  x -= (input_string.length() * (size + letter_distance));
  for (int i = 0; i < input_string.length(); i++)
  {
    char letter = input_string.charAt(i);
    int offset = i * (size + letter_distance);
    render_letter(letter, x, y, offset, size);
  }
}


//Renders a string starting from the center
void XYdraw::render_center_string(String input_string, int x, int y, int size, int letter_distance)
{
  x -= ((input_string.length() * (size + letter_distance))) * 0.5;
  for (int i = 0; i < input_string.length(); i++)
  {
    char letter = input_string.charAt(i);
    int offset = i * (size + letter_distance);
    render_letter(letter, x, y, offset, size);
  }
}
