//XYdraw library header file
//ESP32
//2024/07/25
//Nemes Dániel

#ifndef XYdraw_h
#define XYdraw_h

#include <Arduino.h>

class XYdraw
{
  public:
    XYdraw(int ch_x_pin, int ch_y_pin, int refine);
    void begin();
    void setRefine(int refine);
    void line(int start_x, int start_y, int end_x, int end_y);
    void circle(int origin_x, int origin_y, int radius);
    void bezier_curve(int anchor1_x, int anchor1_y, int anchor2_x, int anchor2_y, int cp1_x, int cp1_y, int cp2_x, int cp2_y);
    void zero(int x, int y, int size);
    void one(int x, int y, int size);
    void two(int x, int y, int size);
    void three(int x, int y, int size);
    void four(int x, int y, int size);
    void five(int x, int y, int size);
    void six(int x, int y, int size);
    void seven(int x, int y, int size);
    void eight(int x, int y, int size);
    void nine(int x, int y, int size);
    void render_string(String input_string, int x, int y, int size, int letter_distance);
    void render_reverse_string(String input_string, int x, int y, int size, int letter_distance);
private:
    int _ch_x_pin;
    int _ch_y_pin;
    int _refine;
};

#endif