//XYdraw library header file
//ESP32
//2024/07/25
//Nemes Dániel

#ifndef XYdraw_h
#define XYdraw_h

#include <Arduino.h>

class XYdraw
{
  public:
    XYdraw(int ch_x_pin, int ch_y_pin, int refine);
    void begin();
    void setRefine(int refine);
    void line(int start_x, int start_y, int end_x, int end_y);
    void rectangle(int x, int y, int x_length, int y_length);
    void circle(int origin_x, int origin_y, int radius);
    void bezier_curve(int anchor1_x, int anchor1_y, int anchor2_x, int anchor2_y, int cp1_x, int cp1_y, int cp2_x, int cp2_y);

    void minus(int x, int y, int size);
    void zero(int x, int y, int size);
    void one(int x, int y, int size);
    void two(int x, int y, int size);
    void three(int x, int y, int size);
    void four(int x, int y, int size);
    void five(int x, int y, int size);
    void six(int x, int y, int size);
    void seven(int x, int y, int size);
    void eight(int x, int y, int size);
    void nine(int x, int y, int size);

    void DRAW_A(int x, int y, int size);
    void DRAW_B(int x, int y, int size);
    void DRAW_C(int x, int y, int size);
    void DRAW_D(int x, int y, int size);
    void DRAW_E(int x, int y, int size);
    void DRAW_F(int x, int y, int size);
    void DRAW_G(int x, int y, int size);
    void DRAW_H(int x, int y, int size);
    void DRAW_I(int x, int y, int size);
    void DRAW_J(int x, int y, int size);
    void DRAW_K(int x, int y, int size);
    void DRAW_L(int x, int y, int size);
    void DRAW_M(int x, int y, int size);
    void DRAW_N(int x, int y, int size);
    void DRAW_O(int x, int y, int size);
    void DRAW_P(int x, int y, int size);
    void DRAW_Q(int x, int y, int size);
    void DRAW_R(int x, int y, int size);
    void DRAW_S(int x, int y, int size);
    void DRAW_T(int x, int y, int size);
    void DRAW_U(int x, int y, int size);
    void DRAW_V(int x, int y, int size);
    void DRAW_W(int x, int y, int size);
    void DRAW_X(int x, int y, int size);
    void DRAW_Y(int x, int y, int size);
    void DRAW_Z(int x, int y, int size);

    void DRAW_a(int x, int y, int size);
    void DRAW_b(int x, int y, int size);
    void DRAW_c(int x, int y, int size);
    void DRAW_d(int x, int y, int size);
    void DRAW_e(int x, int y, int size);
    void DRAW_f(int x, int y, int size);
    void DRAW_g(int x, int y, int size);
    void DRAW_h(int x, int y, int size);
    void DRAW_i(int x, int y, int size);
    void DRAW_j(int x, int y, int size);
    void DRAW_k(int x, int y, int size);
    void DRAW_l(int x, int y, int size);
    void DRAW_m(int x, int y, int size);
    void DRAW_n(int x, int y, int size);
    void DRAW_o(int x, int y, int size);
    void DRAW_p(int x, int y, int size);
    void DRAW_q(int x, int y, int size);
    void DRAW_r(int x, int y, int size);
    void DRAW_s(int x, int y, int size);
    void DRAW_t(int x, int y, int size);
    void DRAW_u(int x, int y, int size);
    void DRAW_v(int x, int y, int size);
    void DRAW_w(int x, int y, int size);
    void DRAW_x(int x, int y, int size);
    void DRAW_y(int x, int y, int size);
    void DRAW_z(int x, int y, int size);

    void render_letter(char letter, int x, int y, int offset, int size);
    void render_string(String input_string, int x, int y, int size, int letter_distance);
    void render_reverse_string(String input_string, int x, int y, int size, int letter_distance);
    void render_center_string(String input_string, int x, int y, int size, int letter_distance);

private:
    int _ch_x_pin;
    int _ch_y_pin;
    int _refine;
    
};

#endif